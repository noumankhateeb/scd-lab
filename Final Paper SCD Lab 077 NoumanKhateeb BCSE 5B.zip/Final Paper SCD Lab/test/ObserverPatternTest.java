/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stu
 */
public class ObserverPatternTest {
    
    public ObserverPatternTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getState method, of class ObserverPattern.
     */
    @Test
    public void testGetState() {
        System.out.println("getState");
        ObserverPattern instance = new ObserverPattern();
        int expResult = 0;
        int result = instance.getState();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setState method, of class ObserverPattern.
     */
    @Test
    public void testSetState() {
        System.out.println("setState");
        int state = 0;
        ObserverPattern instance = new ObserverPattern();
        instance.setState(state);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of attach method, of class ObserverPattern.
     */
    @Test
    public void testAttach() {
        System.out.println("attach");
        Observer observer = null;
        ObserverPattern instance = new ObserverPattern();
        instance.attach(observer);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of notifyAllObservers method, of class ObserverPattern.
     */
    @Test
    public void testNotifyAllObservers() {
        System.out.println("notifyAllObservers");
        ObserverPattern instance = new ObserverPattern();
        instance.notifyAllObservers();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

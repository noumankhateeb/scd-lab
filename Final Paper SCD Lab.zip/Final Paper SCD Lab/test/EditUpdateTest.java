/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stu
 */
public class EditUpdateTest {
    
    public EditUpdateTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Table method, of class EditUpdate.
     */
    @Test
    public void testTable() {
        System.out.println("Table");
        EditUpdate instance = new EditUpdate();
        instance.Table();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Update method, of class EditUpdate.
     */
    @Test
    public void testUpdate() {
        System.out.println("Update");
        String id = "";
        String name = "";
        String classs = "";
        String section = "";
        EditUpdate instance = new EditUpdate();
        int expResult = 0;
        int result = instance.Update(id, name, classs, section);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class EditUpdate.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        EditUpdate.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
